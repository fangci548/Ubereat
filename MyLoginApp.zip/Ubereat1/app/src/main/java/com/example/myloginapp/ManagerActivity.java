package com.example.myloginapp;

public class ManagerActivity {

}
